'use client';
import { useState } from 'react';
import { CircleAlert, LoaderCircle, Save } from 'lucide-react';
import { useServerForm } from '@/components/useServerForm';
import { showToast } from '@/components/Toaster';
import { MAKS_KOP_BYTE, URL_KOP, URL_KOP_BAWAAN, type PengaturanKartu } from '@/lib/kartu-ujian';
import { simpanPengaturanKartu } from './actions';

// Tiga isian header kartu + unggah gambar kop. Tombol simpan menyimpan semuanya sekaligus.
export default function PengaturanForm({ p }: { p: PengaturanKartu }) {
  const [pratinjau, setPratinjau] = useState<string | null>(null); // gambar yang baru dipilih (belum disimpan)
  const [hapus, setHapus] = useState(false);
  const [salahFile, setSalahFile] = useState<string | null>(null);
  const { pending, error, onSubmit } = useServerForm(simpanPengaturanKartu, (r) => { showToast(r.msg, !!r.warn); setPratinjau(null); setHapus(false); });

  const kopSekarang = hapus ? URL_KOP_BAWAAN : pratinjau ?? (p.ada_kop ? `${URL_KOP}?v=${p.versi}` : URL_KOP_BAWAAN);

  function pilihFile(f: File | null) {
    setSalahFile(null); setPratinjau(null);
    if (!f) return;
    if (f.size > MAKS_KOP_BYTE) { setSalahFile('Ukuran gambar maksimal 1 MB'); return; }
    setHapus(false);
    setPratinjau(URL.createObjectURL(f));
  }

  return (
    <form onSubmit={onSubmit} className="panel-body">
      {(error || salahFile) && <div className="alert alert-error" role="alert"><CircleAlert size={18} /><span>{error ?? salahFile}</span></div>}
      <div className="form-grid">
        <label className="field">Jenis ujian
          <input name="jenis_ujian" defaultValue={p.jenis_ujian} required maxLength={100} />
          <small>Judul besar di kartu, contoh Ujian Tengah Semester 1</small>
        </label>
        <label className="field">Madrasah yang melaksanakan ujian
          <input name="madrasah" defaultValue={p.madrasah} required maxLength={100} />
        </label>
        <label className="field">Tahun ajaran
          <input name="tahun_ajaran" defaultValue={p.tahun_ajaran} required maxLength={50} />
          <small>Tulisan &quot;Tahun Ajaran :&quot; ditambahkan otomatis</small>
        </label>
      </div>
      <div className="kop-atur">
        <div className="kop-gambar">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={kopSekarang} alt="Kop kartu" /></div>
        <div>
          <label className="field">Kop / logo atas kartu
            <input type="file" name="kop" accept="image/png,image/jpeg,image/webp" onChange={(e) => pilihFile(e.target.files?.[0] ?? null)} />
            <small>PNG, JPG, atau WEBP, maksimal 1 MB. Tampil di tengah atas kartu. Kosong = logo madrasah bawaan.</small>
          </label>
          {(p.ada_kop || pratinjau) && (
            <label className="kop-hapus"><input type="checkbox" name="hapus_kop" value="1" checked={hapus} onChange={(e) => setHapus(e.target.checked)} disabled={!!pratinjau} /> Hapus kop unggahan, kembali ke logo bawaan</label>
          )}
        </div>
      </div>
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={pending || !!salahFile}>
          {pending ? <LoaderCircle size={16} className="spin" /> : <Save size={16} />}{pending ? 'Menyimpan…' : 'Simpan pengaturan'}
        </button>
      </div>
    </form>
  );
}
