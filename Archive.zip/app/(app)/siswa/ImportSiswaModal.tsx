'use client';
import { useRef, useState, useTransition } from 'react';
import { CircleAlert, FileSpreadsheet, LoaderCircle, RefreshCw, Upload, X } from 'lucide-react';
import Modal from '@/components/Modal';
import { useModalOpener } from '@/components/OpenModal';
import { showToast } from '@/components/Toaster';
import type { Pratinjau } from '@/lib/siswa-types';
import { importSiswaExcel, pratinjauSiswa } from './actions';

const STATUS = {
  baru: ['Baru', 'badge-green'],
  perbarui: ['Diperbarui', 'badge-blue'],
  error: ['Error', 'badge-red'],
} as const;
const TAMPIL_MAKS = 500;

export default function ImportSiswaModal() {
  const [buka, setBuka] = useState(false);
  useModalOpener('siswa-import', () => setBuka(true));
  if (!buka) return null;
  return (
    <Modal title="Upload data siswa dari Excel" icon={<FileSpreadsheet size={17} />} wide onClose={() => setBuka(false)}>
      <Isi onTutup={() => setBuka(false)} />
    </Modal>
  );
}

function Isi({ onTutup }: { onTutup: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [hasil, setHasil] = useState<Pratinjau | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hanyaError, setHanyaError] = useState(false);
  const [membaca, bacaTransition] = useTransition();
  const [menyimpan, simpanTransition] = useTransition();
  const input = useRef<HTMLInputElement>(null);

  function pilih(f: File | null) {
    setFile(f); setHasil(null); setError(null); setHanyaError(false);
    if (!f) return;
    const fd = new FormData();
    fd.set('file', f);
    bacaTransition(async () => {
      try {
        const r = await pratinjauSiswa(fd);
        if (r.ok === false) setError(r.msg); else setHasil(r);
      } catch {
        setError('Gagal menghubungi server. Coba lagi.');
      }
    });
  }

  function ulang() {
    setFile(null); setHasil(null); setError(null);
    if (input.current) input.current.value = '';
  }

  function impor() {
    if (!file) return;
    const fd = new FormData();
    fd.set('file', file);
    setError(null);
    simpanTransition(async () => {
      try {
        const r = await importSiswaExcel(fd);
        if (r.ok) { onTutup(); showToast(r.msg, !!r.warn); } else setError(r.msg);
      } catch {
        setError('Gagal menghubungi server. Coba lagi.');
      }
    });
  }

  const valid = hasil?.ok ? hasil.baru + hasil.perbarui : 0;
  const baris = hasil?.ok ? (hanyaError ? hasil.rows.filter((r) => r.status === 'error') : hasil.rows) : [];

  return (
    <div>
      {error && <div className="alert alert-error" role="alert"><CircleAlert size={18} /><span>{error}</span></div>}

      {!hasil && (
        <label className="dropzone" style={{ opacity: membaca ? .6 : 1 }}>
          {membaca ? <LoaderCircle size={28} className="spin" /> : <Upload size={28} />}
          <strong>{membaca ? 'Membaca file…' : 'Pilih file Excel (.xlsx)'}</strong>
          <span className="muted">Gunakan template dari menu Tambah siswa → Unduh template. Anda akan melihat pratinjau sebelum data disimpan.</span>
          <input
            ref={input} type="file" hidden disabled={membaca}
            accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"
            onChange={(e) => pilih(e.target.files?.[0] ?? null)}
          />
        </label>
      )}

      {hasil?.ok && (
        <>
          <div className="preview-sum">
            <strong>{hasil.namaFile}</strong>
            <span className="badge badge-gray">{hasil.total} baris</span>
            <span className="badge badge-green">{hasil.baru} baru</span>
            <span className="badge badge-blue">{hasil.perbarui} diperbarui</span>
            {hasil.error > 0 && <span className="badge badge-red">{hasil.error} error</span>}
            {hasil.error > 0 && (
              <label style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginLeft: 'auto' }}>
                <input type="checkbox" style={{ width: 'auto', minHeight: 0 }} checked={hanyaError} onChange={(e) => setHanyaError(e.target.checked)} />
                Hanya tampilkan error
              </label>
            )}
          </div>
          {hasil.error > 0 && (
            <div className="alert alert-warn" role="status">
              <CircleAlert size={18} />
              <span>Baris error tidak akan diimpor. Perbaiki di Excel lalu unggah ulang, atau lanjutkan untuk mengimpor {valid} baris yang valid saja.</span>
            </div>
          )}
          <div className="preview-scroll">
            <table>
              <thead>
                <tr><th>Baris</th><th>Status</th><th>No. induk</th><th>Nama</th><th>Asrama</th><th>Kelas</th><th>RFID</th><th>Ruang</th><th>Gelombang</th><th>Keterangan</th></tr>
              </thead>
              <tbody>
                {baris.slice(0, TAMPIL_MAKS).map((r) => {
                  const [label, cls] = STATUS[r.status];
                  const kosong = <span className="muted">-</span>;
                  return (
                    <tr key={r.baris} className={r.status === 'error' ? 'row-error' : undefined}>
                      <td className="num">{r.baris}</td>
                      <td><span className={`badge ${cls}`}>{label}</span></td>
                      <td>{r.no_induk || kosong}</td><td>{r.nama || kosong}</td><td>{r.asrama || kosong}</td><td>{r.kelas || kosong}</td>
                      <td>{r.rfid || kosong}</td><td>{r.kode_ruang || kosong}</td><td>{r.gelombang || kosong}</td>
                      <td className="pesan">{r.pesan}</td>
                    </tr>
                  );
                })}
                {!baris.length && <tr><td colSpan={10} className="empty">Tidak ada baris.</td></tr>}
              </tbody>
            </table>
          </div>
          {baris.length > TAMPIL_MAKS && <p className="muted" style={{ marginTop: 8 }}>Menampilkan {TAMPIL_MAKS} dari {baris.length} baris. Semua baris valid tetap diimpor.</p>}
        </>
      )}

      <div className="preview-actions">
        <button type="button" className="btn" onClick={hasil || file ? ulang : onTutup} disabled={menyimpan || membaca}>
          {hasil || file ? <><RefreshCw size={16} />Ganti file</> : <><X size={16} />Batal</>}
        </button>
        {hasil?.ok && (
          <button type="button" className="btn btn-primary" onClick={impor} disabled={menyimpan || valid === 0}>
            {menyimpan ? <LoaderCircle size={16} className="spin" /> : <Upload size={16} />}
            {menyimpan ? 'Mengimpor…' : `Import ${valid} siswa`}
          </button>
        )}
      </div>
    </div>
  );
}
