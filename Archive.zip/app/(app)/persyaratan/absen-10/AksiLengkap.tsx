'use client';
import { useTransition } from 'react';
import { CircleCheck, LoaderCircle, Undo2 } from 'lucide-react';
import { showToast } from '@/components/Toaster';
import { setLengkapAbsen10 } from '../actions';

// Tombol pengampu: tandai lengkap, atau batalkan bila salah klik.
export default function AksiLengkap({ siswaId, nama, lengkap }: { siswaId: number; nama: string; lengkap: boolean }) {
  const [pending, mulai] = useTransition();

  function kirim() {
    if (lengkap && !confirm(`Batalkan status lengkap untuk ${nama}?`)) return;
    mulai(async () => {
      try {
        const r = await setLengkapAbsen10(siswaId, !lengkap);
        showToast(r.ok ? `${nama}: ${r.msg.toLowerCase()}` : r.msg, !r.ok);
      } catch {
        showToast('Gagal menghubungi server. Coba lagi.', true);
      }
    });
  }

  return lengkap ? (
    <button type="button" className="btn btn-sm" onClick={kirim} disabled={pending}>
      {pending ? <LoaderCircle size={14} className="spin" /> : <Undo2 size={14} />}Batalkan
    </button>
  ) : (
    <button type="button" className="btn btn-sm btn-primary" onClick={kirim} disabled={pending}>
      {pending ? <LoaderCircle size={14} className="spin" /> : <CircleCheck size={14} />}Lengkap
    </button>
  );
}
